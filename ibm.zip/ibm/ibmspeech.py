import speech_recognition as sr
from time import gmtime, strftime 
wordlist = 'abduction accomplice addict alias amber alert anonymous call APB apprehend armed robbery arrest warrant arson assault at large attempted murder auto theft ballistics battery behind bars birth certificate blackmail blotter bootleg bribe bring in buck burglary bust canvass capital crime carcass Caucasian circumstantial evidence complicity con confession convict cordon corpse crack crime criminal act criminal investigation culprit custody death row inmate deceased deputy detective dispute DMV Department Motor Vehicles driving under influence eavesdrop embezzle exclusive ex-con execute extortion felon felony fetus fingerprint flask Ford Crown Victoria forgery Formica topped table foul play fraud frisk fugitive goon grand gut feeling handcuff heinous act hit and run homicide hostage hunch hypnosis illicit impound incarcerate incest incriminate interrogation IRS jail jail time John Doe joint jurisdiction juvie K-9 Kevlar latent print latex gloves law enforcement officer libel lockup loose ends loot manacle manslaughter mass murder Miranda warning misdemeanor modus operandi molest mug shot mugger mutilate muzzle nab narcotic investigator next kin duty parole parole officer patroll car pawn shop penitentiary perpetrator pervert phony pimp plain-clothes cop plot point blank polygraph porn private detective profile prostitute pseudonym psychopath Quantico raid ransom rap sheet real estate Realtor reckless driving ricochet round sawhorse serial killer shackle shell casing sheriff sideburns slander slay sleuth slug smuggle snatch sociopath solar plexus stab state trooper stiff stone strangle stub stubble styrofoam suffocate surveillance suspect tail theft thug torture trauma truncheon turn in undercover investigation UNSUB UPS vault vice squad vindicate warden weed wino gun bom C4 knife kill Allahu Akbar'

# obtain audio from the microphone
r = sr.Recognizer()

end = 0
while end == 0:
    f=open("warning.txt",'a')
    end = 1
    with sr.Microphone() as source:
        print("Say something!")
        audio = r.listen(source)

    try:
        # for testing purposes, we're just using the default API key
        # to use another API key, use `r.recognize_google(audio, key="GOOGLE_SPEECH_RECOGNITION_API_KEY")`
        # instead of `r.recognize_google(audio)`
        print("Watson thinks you said " + r.recognize_google(audio)) 
        if len(set(r.recognize_google(audio).split(' ')) & set(wordlist.split(' ')))>0:
            print("Alert",set(r.recognize_google(audio).split(' ')) & set(wordlist.split(' ')))
            f.write(strftime("%Y-%m-%d %H:%M:%S", gmtime())+'\nContents:'+r.recognize_google(audio)+'\n')
    except sr.UnknownValueError:
        print("Watson could not understand audio")
    except sr.RequestError as e:
        print("Watson could not understand audio; {0}".format(e))
    f.close()
    end = 0
# -*- coding: utf-8 -*-
from tkinter import *
import webbrowser

def onGo():
    webbrowser.open('http://127.0.0.1:5000')
    def counter(i):
        if i > 0:
            t.delete(0.0, END)
            f = open("warning.txt", 'r')
            warning = f.read()
            t.insert(END, warning)
            t.after(1000, counter, i - 1)
            f.close()

        else:

            goBtn.config(state=NORMAL)

    goBtn.config(state=DISABLED)

    counter(1000)


root = Tk()

t = Text(root,font = 'Helvetica -20 bold')

t.pack()

goBtn = Button(text="Go!", command=onGo)

goBtn.pack()

root.mainloop()